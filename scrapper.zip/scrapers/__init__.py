"""
Scrapers package for financial regulatory bodies
"""

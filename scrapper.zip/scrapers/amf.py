#!/usr/bin/env python3
"""
Scrape news from AMF (Autorité des marchés financiers - French Financial Markets Authority)
https://www.amf-france.org/en/news-publications/news

Uses Selenium to handle JavaScript-rendered DataTables content.
"""

import requests
from bs4 import BeautifulSoup
import csv
from pathlib import Path
from datetime import datetime
import time
import re
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException

USER_AGENT = "FinancialComplianceBot/1.0 (research@example.com)"

def get(url, max_retries=3):
    """HTTP GET with retries"""
    headers = {"User-Agent": USER_AGENT}
    for attempt in range(max_retries):
        try:
            r = requests.get(url, headers=headers, timeout=30)
            r.raise_for_status()
            return r
        except requests.RequestException as e:
            if attempt == max_retries - 1:
                raise
            print(f"Retry {attempt+1} after error: {e}")
            time.sleep(2 ** attempt)

def parse_date(date_str):
    """Parse date from AMF format"""
    try:
        # Try common formats
        # Example: "3 November 2025", "26/11/2024" or "November 26, 2024"
        for fmt in ["%d %B %Y", "%d/%m/%Y", "%m/%d/%Y", "%Y-%m-%d", "%B %d, %Y"]:
            try:
                return datetime.strptime(date_str.strip(), fmt)
            except:
                pass
        return None
    except:
        return None

def extract_article_text(url):
    """Extract main article text from AMF article page"""
    try:
        r = get(url)
        soup = BeautifulSoup(r.content, 'lxml')
        
        # Try to find the main content area
        main_content = soup.find('div', class_='layout-content')
        if not main_content:
            main_content = soup.find('main')
        if not main_content:
            main_content = soup.find('article')
        
        if main_content:
            # Remove scripts, styles, navigation
            for tag in main_content.find_all(['script', 'style', 'nav', 'header', 'footer']):
                tag.decompose()
            
            # Get text
            text = main_content.get_text(separator='\n', strip=True)
            # Clean up multiple newlines
            text = re.sub(r'\n\s*\n+', '\n\n', text)
            return text
        
        return ""
    except Exception as e:
        print(f"Error extracting text from {url}: {e}")
        return ""

def safe_filename(title, date):
    """Create a safe filename"""
    # Clean title
    clean = re.sub(r'[<>:"/\\|?*]', '', title)
    clean = re.sub(r'\s+', ' ', clean).strip()
    # Truncate if too long
    if len(clean) > 150:
        clean = clean[:150]
    
    date_str = date.strftime("%Y-%m-%d")
    return f"{date_str} {clean}.txt"

def ensure_unique(filepath):
    """Ensure filename is unique by adding counter if needed"""
    if not filepath.exists():
        return filepath
    
    stem = filepath.stem
    suffix = filepath.suffix
    parent = filepath.parent
    counter = 1
    
    while True:
        new_name = f"{stem} ({counter}){suffix}"
        new_path = parent / new_name
        if not new_path.exists():
            return new_path
        counter += 1

def get_chrome_driver():
    """Initialize Chrome driver with appropriate options"""
    chrome_options = Options()
    chrome_options.add_argument('--headless')  # Run in background
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    chrome_options.add_argument(f'user-agent={USER_AGENT}')
    
    driver = webdriver.Chrome(options=chrome_options)
    return driver

def crawl_month(year, month, out_root):
    """Crawl AMF news for a specific month using Selenium"""
    out_root = Path(out_root)
    month_dir = out_root / f"{year}-{month:02d}"
    text_dir = month_dir / "html_text"
    text_dir.mkdir(parents=True, exist_ok=True)
    
    manifest_path = month_dir / "manifest.csv"
    
    # AMF News page with JavaScript DataTables
    news_url = "https://www.amf-france.org/en/news-publications/news"
    
    print(f"\nInitializing Selenium Chrome driver...")
    driver = None
    
    try:
        driver = get_chrome_driver()
        print(f"Fetching page: {news_url}")
        driver.get(news_url)
        
        # Wait for DataTable to load (wait for tbody to have rows)
        print("Waiting for JavaScript content to load...")
        try:
            wait = WebDriverWait(driver, 20)
            wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "table.datatable tbody tr")))
            print("✓ Content loaded")
        except TimeoutException:
            print("WARNING: Timeout waiting for table rows to load")
            print("The page may not have loaded correctly")
        
        # Give it an extra moment for all content to render
        time.sleep(0.5)  # Reduced from 2
        
        # Get page source after JavaScript execution
        page_source = driver.page_source
        soup = BeautifulSoup(page_source, 'lxml')
        
        # Find the DataTable
        table = soup.find('table', class_='datatable')
        if not table:
            print("ERROR: Could not find DataTable")
            return
        
        tbody = table.find('tbody')
        if not tbody:
            print("ERROR: Could not find tbody")
            return
        
        rows = tbody.find_all('tr')
        print(f"Found {len(rows)} rows in table")
        
        if not rows:
            print("WARNING: No rows found in table tbody")
            return
        
        target_start = datetime(year, month, 1)
        if month == 12:
            target_end = datetime(year + 1, 1, 1)
        else:
            target_end = datetime(year, month + 1, 1)
        
        manifest_rows = []
        
        # Process each row
        for row in rows:
            cells = row.find_all('td')
            if len(cells) < 3:
                continue
            
            # Typical structure: Date | Topic | Title (with link)
            date_cell = cells[0]
            topic_cell = cells[1]
            title_cell = cells[2]
            
            # Extract date
            date_str = date_cell.get_text(strip=True)
            pub_date = parse_date(date_str)
            
            if not pub_date:
                # Try to find date in datetime attribute
                date_elem = date_cell.find(attrs={'datetime': True})
                if date_elem:
                    pub_date = parse_date(date_elem['datetime'])
                
                if not pub_date:
                    print(f"  Could not parse date: {date_str}")
                    continue
            
            # Check if in target month
            if not (target_start <= pub_date < target_end):
                continue
            
            # Extract title and link
            link_elem = title_cell.find('a', href=True)
            if not link_elem:
                continue
            
            title = link_elem.get_text(strip=True)
            link = link_elem['href']
            
            # Make absolute URL
            if not link.startswith('http'):
                link = f"https://www.amf-france.org{link}"
            
            print(f"  {pub_date.strftime('%Y-%m-%d')} - {title}")
            
            # Extract article text
            text = extract_article_text(link)
            if not text:
                print(f"    WARNING: No text extracted")
                continue
            
            # Save text file
            filename = safe_filename(title, pub_date)
            filepath = ensure_unique(text_dir / filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(text)
            
            # Add to manifest
            manifest_rows.append({
                'date': pub_date.strftime('%Y-%m-%d'),
                'title': title,
                'url': link,
                'filename': filepath.name
            })
        
        # Write manifest
        if manifest_rows:
            with open(manifest_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=['date', 'title', 'url', 'filename'])
                writer.writeheader()
                writer.writerows(manifest_rows)
            
            print(f"\n✓ Collected {len(manifest_rows)} news items for {year}-{month:02d}")
            print(f"  Manifest: {manifest_path}")
            print(f"  Text files: {text_dir}")
        else:
            print(f"\n✗ No news items found for {year}-{month:02d}")
    
    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        if driver:
            driver.quit()
            print("Chrome driver closed")

if __name__ == "__main__":
    # Test with October 2025 (we saw dates from this month in the table)
    crawl_month(2025, 10, "amf_out")

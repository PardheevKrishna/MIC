#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DFS NY Press Releases — month harvester (pattern probing, DFS-specific content extraction)

- Probes URLs: https://www.dfs.ny.gov/reports_and_publications/press_releases/prYYYYMMDD[variant]
- Extracts full article text from DFS/Drupal containers:
    .field--name-body, .node__content, #block-dfs-content, [role="main"], main article, etc.
- Saves: dfs_out/YYYY-MM/html_text/YYYY-MM-DD <Title>.txt
- Writes: dfs_out/YYYY-MM/manifest.csv
- No PDF logic (DFS PR pages are HTML-only per your note).

Usage:
  pip install requests beautifulsoup4 lxml
  python dfs.py --year 2025 --month 10 [--out dfs_out]
"""

import csv
import os
import re
import json
import time
import html
import pathlib
import random
import datetime as dt
from typing import List, Optional, Dict
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup

BASE = "https://www.dfs.ny.gov"
PR_BASE = BASE + "/reports_and_publications/press_releases"

SESSION = requests.Session()
SESSION.headers.update({
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/127.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Connection": "keep-alive",
})

# ---------- knobs ----------
REQUEST_TIMEOUT = 20  # Reduced from 35
RETRY_BACKOFF_BASE = 0.3  # Reduced from 0.6
PAUSE = (0.05, 0.15)   # Reduced from (0.12, 0.28) - polite delay between requests
# extend if you ever see other DFS suffixes (e.g., "-01")
VARIANTS = ["", "-1", "-2", "a", "-a", "b", "-b"]
MAX_FILENAME_LEN = 150
MIN_CONTENT_CHARS = 300   # warn + broaden fallback if below this

# ---------- utils ----------
def snooze():
    time.sleep(random.uniform(*PAUSE))

def backoff_sleep(attempt: int):
    time.sleep(RETRY_BACKOFF_BASE * (2 ** attempt) + random.uniform(0, 0.25))

def ymd_range(year: int, month: int) -> List[dt.date]:
    start = dt.date(year, month, 1)
    end = dt.date(year + (month // 12), (month % 12) + 1, 1)
    days = (end - start).days
    return [start + dt.timedelta(days=i) for i in range(days)]

def safe_filename(s: str, maxlen: int = MAX_FILENAME_LEN) -> str:
    s = re.sub(r"[^\w\-.() ]+", "_", s.strip())
    s = re.sub(r"[ _]{2,}", " ", s)
    if len(s) > maxlen:
        stem, ext = os.path.splitext(s)
        s = stem[: maxlen - len(ext) - 1] + "_" + ext
    return s or "file"

def ensure_unique_path(path: pathlib.Path) -> pathlib.Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        return path
    stem, ext = path.stem, path.suffix
    i = 2
    while True:
        cand = path.with_name(f"{stem} ({i}){ext}")
        if not cand.exists():
            cand.parent.mkdir(parents=True, exist_ok=True)
            return cand
        i += 1

def get(url: str, accept: Optional[str] = None, retries: int = 3) -> Optional[requests.Response]:
    for attempt in range(retries):
        try:
            headers = {}
            if accept:
                headers["Accept"] = accept
            r = SESSION.get(url, timeout=REQUEST_TIMEOUT, headers=headers, allow_redirects=True)
            # must be HTML; ignore 3xx/4xx/5xx
            if 200 <= r.status_code < 300 and "text/html" in r.headers.get("Content-Type",""):
                return r
            if r.status_code in (403, 406, 429) or 500 <= r.status_code < 600:
                backoff_sleep(attempt); continue
            return None
        except requests.RequestException:
            backoff_sleep(attempt)
    return None

def get_soup(url: str) -> Optional[BeautifulSoup]:
    r = get(url, accept="text/html,*/*;q=0.8", retries=3)
    if not r:
        return None
    return BeautifulSoup(r.text, "lxml")

# ---------- date parsing ----------
PR_URL_DATE_RE = re.compile(r"/pr(20\d{2})(\d{2})(\d{2})(?:\D|$)")
ISO_DATE_RE = re.compile(r"\b(20\d{2})-(\d{2})-(\d{2})\b")
DATE_EN_COMMA_RE = re.compile(
    r"\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2}),\s+(20\d{2})\b",
    re.IGNORECASE
)
MONTHS_EN = {m.lower(): i+1 for i, m in enumerate(
    ["January","February","March","April","May","June","July","August","September","October","November","December"]
)}

def parse_pr_date_from_url(url: str) -> Optional[dt.date]:
    m = PR_URL_DATE_RE.search(url)
    if not m: return None
    y, mm, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
    try: return dt.date(y, mm, dd)
    except ValueError: return None

def parse_iso_date(s: str) -> Optional[dt.date]:
    m = ISO_DATE_RE.search(s or "")
    if not m: return None
    y, mm, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
    try: return dt.date(y, mm, dd)
    except ValueError: return None

def parse_en_comma_date(s: str) -> Optional[dt.date]:
    m = DATE_EN_COMMA_RE.search(s or "")
    if not m: return None
    mon = MONTHS_EN[m.group(1).lower()]
    day = int(m.group(2)); year = int(m.group(3))
    try: return dt.date(year, mon, day)
    except ValueError: return None

def resolve_date_from_page(url: str, soup: BeautifulSoup, guess: Optional[dt.date]) -> Optional[dt.date]:
    # 1) JSON-LD
    for tag in soup.find_all("script", {"type": "application/ld+json"}):
        try:
            data = json.loads(tag.string or "")
        except Exception:
            continue
        objs = data if isinstance(data, list) else [data]
        for obj in objs:
            if not isinstance(obj, dict): continue
            for k in ("datePublished", "uploadDate", "dateCreated"):
                v = obj.get(k)
                if isinstance(v, str):
                    d = parse_iso_date(v) or parse_en_comma_date(v)
                    if d: return d
    # 2) <time> blocks
    for t in soup.find_all("time"):
        if t.has_attr("datetime"):
            d = parse_iso_date(t["datetime"]) or parse_en_comma_date(t["datetime"])
            if d: return d
        txt = t.get_text(" ", strip=True)
        d = parse_en_comma_date(txt) or parse_iso_date(txt)
        if d: return d
    # 3) whole page scan
    txt = soup.get_text(" ", strip=True)
    d = parse_en_comma_date(txt) or parse_iso_date(txt)
    # 4) fallback to URL date
    return d or parse_pr_date_from_url(url) or guess

# ---------- content extraction (DFS-tuned) ----------
def strip_boilerplate(root: BeautifulSoup):
    # remove obvious non-content
    for sel in [
        "script", "style", "nav", "aside", "header", "footer", "form",
        ".breadcrumb", ".breadcrumbs", ".pager", ".pagination",
        ".share", ".social", ".meta", ".tags", ".related", ".sidebar",
        ".views-exposed-form", ".block-system-breadcrumb-block",
        ".usa-alert", ".usa-banner", ".usa-cookie-banner", ".cookie", ".alert"
    ]:
        for t in root.select(sel):
            t.decompose()
    # hidden stuff
    for t in root.select("[hidden], [aria-hidden='true']"):
        t.decompose()

def extract_title(soup: BeautifulSoup) -> str:
    for sel in ["main h1", "article h1", "h1", "header h1"]:
        el = soup.select_one(sel)
        if el and el.get_text(strip=True):
            return el.get_text(strip=True)
    if soup.title and soup.title.string:
        return soup.title.string.strip()
    return "Untitled"

def extract_main_text_dfs(soup: BeautifulSoup) -> str:
    """
    DFS-specific content pull with layered fallbacks (no .clone() anywhere).
    """
    # 1) High-confidence DFS/Drupal body buckets
    body_selectors = [
        "div.field--name-body",
        "div.node__content",
        "div#block-dfs-content",
        "div.main-content",
        "div.layout-content",
        "div.region-content",
        "section#main-content",
        "div#content",
        "[role='main']",
    ]
    for sel in body_selectors:
        el = soup.select_one(sel)
        if el and el.get_text(strip=True):
            # work on a shallow copy by parsing its HTML again
            el_soup = BeautifulSoup(str(el), "lxml")
            strip_boilerplate(el_soup)
            txt = el_soup.get_text("\n", strip=True)
            txt = html.unescape(re.sub(r"\n{2,}", "\n\n", txt))
            if len(txt) >= MIN_CONTENT_CHARS:
                return txt
            # keep trying broader scopes

    # 2) Generic main/article
    for sel in ["main article", "article", "main"]:
        el = soup.select_one(sel)
        if el and el.get_text(strip=True):
            el_soup = BeautifulSoup(str(el), "lxml")
            strip_boilerplate(el_soup)
            txt = el_soup.get_text("\n", strip=True)
            txt = html.unescape(re.sub(r"\n{2,}", "\n\n", txt))
            if len(txt) >= MIN_CONTENT_CHARS:
                return txt

    # 3) Whole-body fallback
    body = soup.body or soup
    body_soup = BeautifulSoup(str(body), "lxml")
    strip_boilerplate(body_soup)
    txt = body_soup.get_text("\n", strip=True)
    txt = html.unescape(re.sub(r"\n{2,}", "\n\n", txt))
    return txt

# ---------- main ----------
def crawl_month(year: int, month: int, out_root: str = "dfs_out") -> Dict:
    # Prepare dirs
    month_root = pathlib.Path(out_root) / f"{year}-{month:02d}"
    text_dir = month_root / "html_text"
    text_dir.mkdir(parents=True, exist_ok=True)

    # Build candidate URLs by pattern
    candidates: List[str] = []
    for d in ymd_range(year, month):
        base = f"{PR_BASE}/pr{d.year}{d.month:02d}{d.day:02d}"
        for v in VARIANTS:
            candidates.append(base + v)

    print(f"[probe] generated {len(candidates)} URLs for {year}-{month:02d}")

    hits = 0
    manifest: List[Dict[str, str]] = []
    seen = set()

    for url in candidates:
        if url in seen:
            continue
        seen.add(url)

        soup = get_soup(url)
        if not soup:
            continue  # 404 / not HTML

        # Date from URL (authoritative), refined by page if present
        guess_date = parse_pr_date_from_url(url)
        d = resolve_date_from_page(url, soup, guess_date)
        if not d or d.year != year or d.month != month:
            continue

        title = extract_title(soup)
        text = extract_main_text_dfs(soup)

        # If text still short, try a broader <main> sweep once
        if len(text) < MIN_CONTENT_CHARS:
            main = soup.find("main") or soup
            main_soup = BeautifulSoup(str(main), "lxml")
            strip_boilerplate(main_soup)
            broad = main_soup.get_text("\n", strip=True)
            broad = html.unescape(re.sub(r"\n{2,}", "\n\n", broad))
            if len(broad) > len(text):
                text = broad

        # Save text
        fname = safe_filename(f"{d.isoformat()} {title}.txt")
        fpath = ensure_unique_path(text_dir / fname)
        fpath.write_text(text, encoding="utf-8")

        hits += 1
        print(f"  - saved ({hits}): {fpath.name} ({len(text)} chars)")
        manifest.append({
            "date": d.isoformat(),
            "title": title,
            "source_url": url,
            "saved_file": str(fpath),
            "domain": urlparse(url).netloc,
            "chars": str(len(text)),
        })
        snooze()

    # Write manifest
    manifest_path = month_root / "manifest.csv"
    with open(manifest_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f, fieldnames=["date","title","source_url","saved_file","domain","chars"]
        )
        writer.writeheader()
        for row in sorted(manifest, key=lambda r: r["date"]):
            writer.writerow(row)

    print(f"[done] Collected {hits} press release(s) for {year}-{month:02d}")
    print(f"[done] Output dir: {month_root.resolve()}")
    print(f"[done] Manifest: {manifest_path.resolve()}")

    return {
        "year": year, "month": month, "count": hits,
        "output_dir": str(month_root.resolve()),
        "manifest": str(manifest_path.resolve()),
    }

# ---------- CLI ----------
if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="DFS NY press releases harvester (DFS-specific extractor).")
    ap.add_argument("--year", type=int, required=True, help="e.g., 2025")
    ap.add_argument("--month", type=int, required=True, help="1-12")
    ap.add_argument("--out", type=str, default="dfs_out", help="Output directory root")
    args = ap.parse_args()

    if not (1 <= args.month <= 12):
        raise SystemExit("Month must be 1..12")

    try:
        crawl_month(args.year, args.month, args.out)
    except Exception as e:
        raise SystemExit(f"[error] {e}")

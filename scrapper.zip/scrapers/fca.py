#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FCA News harvester (offset pagination; resilient link extraction; robust titles; in-file header)
"""

import csv, os, re, json, time, html, pathlib, random, datetime as dt
from typing import List, Optional, Dict, Tuple
from urllib.parse import urlencode, urljoin, urlparse

import requests
from bs4 import BeautifulSoup

BASE = "https://www.fca.org.uk"
SEARCH_BASE = BASE + "/news/search-results"

SESSION = requests.Session()
SESSION.headers.update({
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
    "Connection": "keep-alive",
})

REQUEST_TIMEOUT = 20  # Reduced from 40
PAUSE = (0.05, 0.12)  # Reduced from (0.10, 0.25)
MAX_FILENAME_LEN = 150
MIN_CONTENT_CHARS = 300
DEFAULT_MAX_PAGES = 500   # allow long result sets
PAGE_SIZE = 10            # FCA shows "1 to 10 of N"

def snooze(): time.sleep(random.uniform(*PAUSE))

def safe_filename(s: str, maxlen: int = MAX_FILENAME_LEN) -> str:
    s = re.sub(r"[^\w\-.() ]+", "_", s.strip())
    s = re.sub(r"[ _]{2,}", " ", s)
    if len(s) > maxlen:
        stem, ext = os.path.splitext(s)
        s = stem[: maxlen - len(ext) - 1] + "_" + ext
    return s or "file"

def ensure_unique_path(path: pathlib.Path) -> pathlib.Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists(): return path
    stem, ext = path.stem, path.suffix; i = 2
    while True:
        cand = path.with_name(f"{stem} ({i}){ext}")
        if not cand.exists(): return cand
        i += 1

def get(url: str) -> Optional[requests.Response]:
    try:
        r = SESSION.get(url, timeout=REQUEST_TIMEOUT, allow_redirects=True)
        if 200 <= r.status_code < 300: return r
    except requests.RequestException:
        return None
    return None

def soup_get(url: str) -> Optional[BeautifulSoup]:
    r = get(url)
    if not r: return None
    return BeautifulSoup(r.text, "lxml")

def month_token(m: int) -> str:
    return ["jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"][m-1]

def build_search_url(year: int, month: int, start: int) -> str:
    params = {
        "n_search_term": "",
        "year": f"f.Published Year|year={year}",  # keep '|' and '=' as literals
        "month": month_token(month),
        "sort_by": "dmetaZ",
        "start": start,  # 1, 11, 21, ...
    }
    qs = urlencode(params, doseq=True, safe="|=")
    return f"{SEARCH_BASE}?{qs}"

COUNT_RE = re.compile(r"Showing\s+\d+\s+to\s+\d+\s+of\s+(\d+)\s+search results", re.I)

def parse_total_and_links(soup: BeautifulSoup) -> Tuple[int, List[str]]:
    # total count
    total = 0
    m = COUNT_RE.search(soup.get_text(" ", strip=True))
    if m: total = int(m.group(1))

    # Prefer result containers; fall back to main
    scope = soup.select_one("main") or soup
    containers = scope.select(".search-results, .search-results__list, ul.search-results, .view-content")
    if not containers: containers = [scope]

    links: List[str] = []

    # Tier 1: per-item headline anchors
    tier1_selectors = [
        "li.search-listing__item h3 a",
        "li.search-listing__item h2 a",
        ".search-results h3 a",
        ".search-results h2 a",
        ".search-results .g-type-body a",
        ".search-results__list h3 a",
        ".view-content h3 a",
    ]
    for container in containers:
        for sel in tier1_selectors:
            for a in container.select(sel):
                href = (a.get("href") or "").strip()
                if not href: continue
                absu = urljoin(BASE, href)
                if not absu.startswith(BASE + "/news/"):  # news-only
                    continue
                if "/news/search-results" in absu:       # avoid nested searches
                    continue
                text = a.get_text(" ", strip=True)
                if not text or text.lower() == "more":
                    continue
                links.append(absu)

    # Tier 2 fallback: any anchor under <main> to a /news/… page (still avoids /news/search-results)
    if not links:
        for a in scope.select("a[href]"):
            href = (a.get("href") or "").strip()
            if not href: continue
            absu = urljoin(BASE, href)
            if not absu.startswith(BASE + "/news/"): 
                continue
            if "/news/search-results" in absu:
                continue
            # exclude obvious non-item links (filters, breadcrumbs)
            txt = a.get_text(" ", strip=True)
            if len(txt) < 2:  # tiny labels like ">" etc.
                continue
            links.append(absu)

    # unique preserve order
    seen, out = set(), []
    for u in links:
        if u not in seen:
            out.append(u); seen.add(u)
    return total, out

# --- date parsing ---
ISO_DATE = re.compile(r"\b(20\d{2})-(\d{2})-(\d{2})\b")
UK_SLASH = re.compile(r"\b(\d{1,2})/(\d{1,2})/(20\d{2})\b")
EN_MONTH_COMMA = re.compile(
    r"\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2}),\s+(20\d{2})\b",
    re.IGNORECASE
)
MONTHS = {m.lower(): i+1 for i, m in enumerate(
    ["January","February","March","April","May","June","July","August","September","October","November","December"]
)}

def parse_iso_date(s: str) -> Optional[dt.date]:
    m = ISO_DATE.search(s or ""); 
    if not m: return None
    y, mm, dd = map(int, m.groups())
    try: return dt.date(y, mm, dd)
    except ValueError: return None

def parse_uk_slash(s: str) -> Optional[dt.date]:
    m = UK_SLASH.search(s or "")
    if not m: return None
    d, mth, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
    try: return dt.date(y, mth, d)
    except ValueError: return None

def parse_en_month_comma(s: str) -> Optional[dt.date]:
    m = EN_MONTH_COMMA.search(s or "")
    if not m: return None
    mon = MONTHS[m.group(1).lower()]
    d = int(m.group(2)); y = int(m.group(3))
    try: return dt.date(y, mon, d)
    except ValueError: return None

def resolve_date(soup: BeautifulSoup) -> Optional[dt.date]:
    for tag in soup.find_all("script", {"type":"application/ld+json"}):
        try: data = json.loads(tag.string or "")
        except Exception: continue
        objs = data if isinstance(data, list) else [data]
        for o in objs:
            if not isinstance(o, dict): continue
            for k in ("datePublished","uploadDate","dateCreated"):
                v = o.get(k)
                if isinstance(v, str):
                    d = parse_iso_date(v) or parse_en_month_comma(v) or parse_uk_slash(v)
                    if d: return d
    for t in soup.find_all("time"):
        if t.has_attr("datetime"):
            d = parse_iso_date(t["datetime"]) or parse_en_month_comma(t["datetime"]) or parse_uk_slash(t["datetime"])
            if d: return d
        txt = t.get_text(" ", strip=True)
        d = parse_en_month_comma(txt) or parse_uk_slash(txt) or parse_iso_date(txt)
        if d: return d
    for node in soup.find_all(string=re.compile(r"Published:", re.I)):
        s = str(node)
        d = parse_uk_slash(s) or parse_en_month_comma(s) or parse_iso_date(s)
        if d: return d
    page = soup.get_text(" ", strip=True)
    return parse_uk_slash(page) or parse_en_month_comma(page) or parse_iso_date(page)

# --- body + title ---
def strip_boilerplate(root: BeautifulSoup):
    for sel in [
        "script","style","nav","aside","header","footer","form",
        ".breadcrumb",".breadcrumbs",".pager",".pagination",
        ".share",".social",".meta",".tags",".related",".sidebar",
        ".cookie",".cookie-banner",".alert",".banner",".promo",".callout",
        ".block-system-breadcrumb-block"
    ]:
        for t in root.select(sel): t.decompose()
    for t in root.select("[hidden], [aria-hidden='true']"): t.decompose()

def extract_title(soup: BeautifulSoup, url: str) -> str:
    # JSON-LD headline/name
    for tag in soup.find_all("script", {"type": "application/ld+json"}):
        try: data = json.loads(tag.string or "")
        except Exception: continue
        objs = data if isinstance(data, list) else [data]
        for o in objs:
            if isinstance(o, dict):
                for k in ("headline", "name"):
                    v = o.get(k)
                    if isinstance(v, str) and v.strip() and v.strip().lower() != "news":
                        return v.strip()
    # meta titles
    for sel in [
        'meta[property="og:title"]',
        'meta[name="title"]',
        'meta[name="dcterms.title"]',
        'meta[name="twitter:title"]'
    ]:
        m = soup.select_one(sel)
        if m:
            v = (m.get("content") or "").strip()
            if v and v.lower() != "news": return v
    # h1
    for sel in ["main h1","article h1","h1","header h1"]:
        el = soup.select_one(sel)
        if el:
            t = el.get_text(" ", strip=True)
            if t and t.lower() != "news": return t
    # slug fallback
    slug = urlparse(url).path.rstrip("/").split("/")[-1]
    slug = re.sub(r"[-_]+", " ", slug).strip() or "Untitled"
    return " ".join(w if w.isupper() else w.capitalize() for w in slug.split())

def extract_body_fca(soup: BeautifulSoup) -> str:
    buckets = [
        ".article-body",".content-body",".wysiwyg",".node__content",
        "div.region-content","main article","article","main","#content",
    ]
    best = ""
    for sel in buckets:
        el = soup.select_one(sel)
        if not el or not el.get_text(strip=True): continue
        sub = BeautifulSoup(str(el), "lxml")
        strip_boilerplate(sub)
        txt = sub.get_text("\n", strip=True)
        txt = html.unescape(re.sub(r"\n{2,}", "\n\n", txt))
        if len(txt) > len(best): best = txt
        if len(txt) >= MIN_CONTENT_CHARS: return txt
    if not best:
        body = soup.body or soup
        sub = BeautifulSoup(str(body), "lxml")
        strip_boilerplate(sub)
        best = html.unescape(re.sub(r"\n{2,}", "\n\n", sub.get_text("\n", strip=True)))
    return best

# --- main ---
def crawl_month(year: int, month: int, out_root: str = "fca_out", max_pages: int = DEFAULT_MAX_PAGES) -> Dict:
    month_root = pathlib.Path(out_root) / f"{year}-{month:02d}"
    text_dir = month_root / "html_text"
    text_dir.mkdir(parents=True, exist_ok=True)

    all_links: List[str] = []
    total_reported = None
    start = 1
    pages_fetched = 0

    while pages_fetched < max_pages:
        url = build_search_url(year, month, start=start)
        soup = soup_get(url)
        if not soup: break

        total, links = parse_total_and_links(soup)
        if total and total_reported is None:
            total_reported = total
            print(f"[index] total reported by site: {total_reported}")

        before = len(all_links)
        for u in links:
            if u not in all_links:
                all_links.append(u)
        gained = len(all_links) - before
        print(f"[index] start={start}: +{gained} links (uniq so far: {len(all_links)})")

        pages_fetched += 1
        if gained == 0: break
        if total_reported and len(all_links) >= total_reported: break

        start += PAGE_SIZE
        snooze()

    print(f"[index] total unique links: {len(all_links)}")

    hits = 0
    manifest: List[Dict[str, str]] = []
    for url in all_links:
        soup = soup_get(url)
        if not soup: continue

        title = extract_title(soup, url)
        date = resolve_date(soup)
        if not (date and date.year == year and date.month == month):
            # page hides the date; trust the month filter and default day=1
            date = dt.date(year, month, 1)

        body = extract_body_fca(soup)
        if len(body) < MIN_CONTENT_CHARS:
            main = soup.find("main") or soup
            sub = BeautifulSoup(str(main), "lxml")
            strip_boilerplate(sub)
            broad = html.unescape(re.sub(r"\n{2,}", "\n\n", sub.get_text("\n", strip=True)))
            if len(broad) > len(body): body = broad

        header = (f"Title: {title}\n"
                  f"Published: {date.isoformat()}\n"
                  f"Source: {url}\n"
                  f"{'-'*80}\n\n")

        fname = safe_filename(f"{date.isoformat()} {title}.txt")
        fpath = ensure_unique_path(text_dir / fname)
        fpath.write_text(header + body, encoding="utf-8")

        hits += 1
        print(f"  - saved ({hits}): {fpath.name} ({len(body)} chars)")
        manifest.append({
            "date": date.isoformat(),
            "title": title,
            "source_url": url,
            "saved_file": str(fpath),
            "domain": urlparse(url).netloc,
            "chars": str(len(body)),
        })
        snooze()

    manifest_path = month_root / "manifest.csv"
    with open(manifest_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["date","title","source_url","saved_file","domain","chars"])
        writer.writeheader()
        for row in sorted(manifest, key=lambda r: r["date"]):
            writer.writerow(row)

    print(f"[done] Collected {hits} FCA news items for {year}-{month:02d}")
    print(f"[done] Output dir: {month_root.resolve()}")
    print(f"[done] Manifest: {manifest_path.resolve()}")

    return {"year":year, "month":month, "count":hits,
            "output_dir": str(month_root.resolve()),
            "manifest": str(manifest_path.resolve())}

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="FCA News harvester (offset pagination; resilient link extraction).")
    ap.add_argument("--year", type=int, required=True)
    ap.add_argument("--month", type=int, required=True)
    ap.add_argument("--out", type=str, default="fca_out")
    ap.add_argument("--max-pages", type=int, default=DEFAULT_MAX_PAGES)
    args = ap.parse_args()
    if not (1 <= args.month <= 12): raise SystemExit("Month must be 1..12")
    crawl_month(args.year, args.month, args.out, args.max_pages)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Federal Reserve press releases fetcher (title-first filenames)
- Input: --year YYYY and --month M[1..12]
- Single-PDF pages => "YYYY-MM-DD <Page Title>.pdf"
- Multi-PDF pages  => "YYYY-MM-DD <Page Title>__<Meaningful Label or Attachment N>.pdf"
- No-PDF pages     => "YYYY-MM-DD <Page Title>.txt"
- Writes manifest.csv with metadata.

Usage:
  pip install requests beautifulsoup4 lxml
  python fed.py --year 2025 --month 10
"""

import csv
import os
import re
import time
import html
import pathlib
import random
from typing import List, Tuple, Dict, Optional
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

# ---------- Constants & Session ----------

BASE = "https://www.federalreserve.gov"
PR_BASE = f"{BASE}/newsevents/pressreleases/"
YEAR_INDEX_TMPL = PR_BASE + "{year}-press.htm"

SESSION = requests.Session()
SESSION.headers.update({
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/127.0.0.0 Safari/537.36"
    ),
    "Accept": "*/*",
    "Accept-Language": "en-US,en;q=0.9",
    "Connection": "keep-alive",
})

DATE_IN_URL = re.compile(r"([a-z]+)(\d{4})(\d{2})(\d{2})([a-z]\d*)?\.htm", re.IGNORECASE)
PDF_PATH = re.compile(r"^/newsevents/pressreleases/files/.*\.pdf$", re.IGNORECASE)

MAX_FILENAME_LEN = 140  # Windows-friendly


# ---------- Helpers ----------

def safe_filename(s: str, maxlen: int = MAX_FILENAME_LEN) -> str:
    s = re.sub(r"[^\w\-.() ]+", "_", s.strip())
    s = re.sub(r"[ _]{2,}", " ", s)
    if len(s) > maxlen:
        stem, ext = os.path.splitext(s)
        s = stem[: maxlen - len(ext) - 1] + "_" + ext
    return s or "file"

def ensure_unique_path(path: pathlib.Path) -> pathlib.Path:
    if not path.exists():
        return path
    stem, ext = path.stem, path.suffix
    i = 2
    while True:
        candidate = path.with_name(f"{stem} ({i}){ext}")
        if not candidate.exists():
            return candidate
        i += 1

def backoff_sleep(attempt: int, base: float = 0.8) -> None:
    time.sleep(base * (2 ** attempt) + random.uniform(0, 0.25))

def get_soup(url: str, *, retries: int = 3, timeout: int = 30) -> BeautifulSoup:
    last_exc = None
    for attempt in range(retries):
        try:
            resp = SESSION.get(url, timeout=timeout)
            if 200 <= resp.status_code < 300:
                return BeautifulSoup(resp.text, "lxml")
            if resp.status_code in (403, 406, 429) or 500 <= resp.status_code < 600:
                backoff_sleep(attempt)
                continue
            resp.raise_for_status()
        except requests.RequestException as exc:
            last_exc = exc
            backoff_sleep(attempt)
    if last_exc:
        raise last_exc
    return BeautifulSoup("", "lxml")

def extract_date_from_url(url: str) -> Optional[str]:
    m = DATE_IN_URL.search(url)
    if not m:
        return None
    yyyy, mm, dd = m.group(2), m.group(3), m.group(4)
    return f"{yyyy}-{mm}-{dd}"

def extract_title(soup: BeautifulSoup) -> str:
    h1 = soup.find("h1")
    if h1 and h1.get_text(strip=True):
        return h1.get_text(strip=True)
    if soup.title and soup.title.string:
        return soup.title.string.strip()
    return "Untitled Press Release"

def find_press_release_links_for_month(year: int, month: int) -> List[str]:
    index_url = YEAR_INDEX_TMPL.format(year=year)
    soup = get_soup(index_url)
    target_prefix = f"{year}{month:02d}"

    links = []
    for a in soup.select("a[href]"):
        href = a["href"]
        if not href.lower().endswith(".htm"):
            continue
        if "/newsevents/pressreleases/" not in href:
            continue
        url = urljoin(BASE, href)
        m = DATE_IN_URL.search(url)
        if not m:
            continue
        yyyymm = m.group(2) + m.group(3)
        if yyyymm == target_prefix:
            links.append(url)

    seen = set()
    uniq = []
    for u in links:
        if u not in seen:
            uniq.append(u)
            seen.add(u)
    return uniq

def is_generic_label(label: str) -> bool:
    """
    Heuristic: treat labels like 'PDF', 'Order (PDF)', 'Press Release (PDF)', 'Attachment', etc. as generic.
    """
    s = label.strip().lower()
    if not s:
        return True
    generic_words = [
        "pdf", "link", "order (pdf)", "press release (pdf)", "attachment", "attachment (pdf)",
        "memo (pdf)", "enforcement action (pdf)", "notice (pdf)"
    ]
    if s in generic_words:
        return True
    # 'Attachment 1 (PDF)' -> specific enough
    if re.fullmatch(r"attachment\s+\d+(\s*\(pdf\))?", s):
        return False
    # If it’s just something like "PDF (79 KB)"
    if "pdf" in s and len(s) <= 15:
        return True
    return False

def extract_pdfs_with_labels_and_text(pr_url: str) -> Tuple[List[Tuple[str, str]], str]:
    """
    Return ([(pdf_url, label)], cleaned_text_if_no_pdfs_else_empty).
    Label is derived from anchor text near the link; may be generic.
    """
    soup = get_soup(pr_url)

    items: List[Tuple[str, str]] = []
    for a in soup.select("a[href]"):
        href = a.get("href", "")
        if PDF_PATH.match(href):
            url = urljoin(BASE, href)
            label = a.get_text(" ", strip=True) or ""
            label = re.sub(r"\s+", " ", label)
            items.append((url, label))

    # de-dupe preserving first label we saw
    seen = set()
    deduped: List[Tuple[str, str]] = []
    for url, label in items:
        if url not in seen:
            deduped.append((url, label))
            seen.add(url)

    if deduped:
        return deduped, ""

    # No PDFs -> extract text
    candidates = []
    for i in ["article", "content", "cms-content", "pr", "main"]:
        el = soup.find(id=i)
        if el:
            candidates.append(el)
    if not candidates:
        candidates = soup.select("main, div.col-xs-12.col-sm-8.col-md-8, div.col-md-8, article")
    root = candidates[0] if candidates else soup.body or soup

    for tag in root.select("script, style, nav, aside, header, footer"):
        tag.decompose()

    text = root.get_text("\n", strip=True)
    text = html.unescape(re.sub(r"\n{2,}", "\n\n", text))
    return [], text

def download_file(url: str, dest_path: pathlib.Path, referer: Optional[str] = None, *, timeout: int = 60, retries: int = 3) -> None:
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    is_pdf = url.lower().endswith(".pdf")

    for attempt in range(retries):
        try:
            headers = {}
            if is_pdf:
                headers.update({
                    "Accept": "application/pdf,application/octet-stream;q=0.9,*/*;q=0.8",
                    "Referer": referer or BASE,
                })

            r = SESSION.get(url, headers=headers or None, stream=True, timeout=timeout)
            if r.status_code in (403, 406):
                r.close()
                fb_headers = {"Accept": "*/*", "Referer": referer or BASE}
                backoff_sleep(attempt)
                r = SESSION.get(url, headers=fb_headers, stream=True, timeout=timeout)

            r.raise_for_status()

            tmp_path = dest_path.with_suffix(dest_path.suffix + ".part")
            with open(tmp_path, "wb") as f:
                for chunk in r.iter_content(chunk_size=128 * 1024):
                    if chunk:
                        f.write(chunk)
            r.close()
            tmp_path.replace(dest_path)
            return
        except requests.RequestException:
            if attempt == retries - 1:
                raise
            backoff_sleep(attempt)


# ---------- Core flow ----------

def fetch_month(year: int, month: int, out_dir: str = "fed_press_out") -> Dict:
    out = pathlib.Path(out_dir) / f"{year}-{month:02d}"
    out.mkdir(parents=True, exist_ok=True)

    pr_links = find_press_release_links_for_month(year, month)
    if not pr_links:
        print(f"[info] No press releases found for {year}-{month:02d}.")
    else:
        print(f"[info] Found {len(pr_links)} press releases for {year}-{month:02d}")

    manifest_rows = []
    for idx_link, pr_url in enumerate(pr_links, start=1):
        time.sleep(0.2)  # Reduced from 0.5
        print(f"[{idx_link}/{len(pr_links)}] Processing: {pr_url}")

        # parse once, reuse title
        soup = get_soup(pr_url)
        title = extract_title(soup)
        date_str = extract_date_from_url(pr_url) or f"{year}-{month:02d}-??"

        pdf_items, text = extract_pdfs_with_labels_and_text(pr_url)
        saved_files: List[str] = []

        if pdf_items:
            # If exactly one PDF, use the page title as the PDF filename (your request)
            if len(pdf_items) == 1:
                pdf_url, _label = pdf_items[0]
                base_name = f"{date_str} {title}"
                fname = safe_filename(f"{base_name}.pdf")
                fpath = ensure_unique_path(out / "pdfs" / fname)
                try:
                    download_file(pdf_url, fpath, referer=pr_url)
                    saved_files.append(str(fpath))
                    print(f"   - saved PDF -> {fpath.name}")
                except Exception as exc:
                    print(f"   ! failed PDF: {pdf_url} -> {exc}")
            else:
                # Multiple PDFs: try to use meaningful labels; otherwise use Attachment N
                for i, (pdf_url, raw_label) in enumerate(pdf_items, start=1):
                    # Clean/semi-meaningful label?
                    label = raw_label.strip()
                    if is_generic_label(label):
                        # Try the PDF basename if it carries meaning (rare), else Attachment N
                        basename = os.path.basename(urlparse(pdf_url).path)
                        # If basename like 'orders20251031a1.pdf' -> generic; keep Attachment N
                        if re.fullmatch(r"[a-z]+[0-9]{8}[a-z][0-9]+\.pdf", basename, re.IGNORECASE):
                            label = f"Attachment {i}"
                        else:
                            label = os.path.splitext(basename)[0]
                    base_name = f"{date_str} {title}"
                    fname = safe_filename(f"{base_name}__{label}.pdf")
                    fpath = ensure_unique_path(out / "pdfs" / fname)
                    try:
                        download_file(pdf_url, fpath, referer=pr_url)
                        saved_files.append(str(fpath))
                        print(f"   - saved PDF {i}/{len(pdf_items)} -> {fpath.name}")
                    except Exception as exc:
                        print(f"   ! failed PDF {i}/{len(pdf_items)}: {pdf_url} -> {exc}")
        else:
            # Save inline text
            fname = safe_filename(f"{date_str} {title}.txt")
            fpath = ensure_unique_path(out / "html_text" / fname)
            fpath.parent.mkdir(parents=True, exist_ok=True)
            fpath.write_text(text, encoding="utf-8")
            saved_files.append(str(fpath))
            print(f"   - saved text -> {fpath.name}")

        manifest_rows.append(
            {
                "date": date_str,
                "title": title,
                "press_release_url": pr_url,
                "assets_saved": " | ".join(saved_files),
                "has_pdfs": "yes" if pdf_items else "no",
                "num_pdfs": len(pdf_items),
            }
        )

    manifest_path = out / "manifest.csv"
    with open(manifest_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "date",
                "title",
                "press_release_url",
                "assets_saved",
                "has_pdfs",
                "num_pdfs",
            ],
        )
        writer.writeheader()
        for row in manifest_rows:
            writer.writerow(row)

    print(f"[done] Saved {len(manifest_rows)} press releases to {out}")
    print(f"[done] Manifest: {manifest_path}")

    return {
        "year": year,
        "month": month,
        "count": len(manifest_rows),
        "output_dir": str(out),
        "manifest": str(manifest_path),
    }


# ---------- CLI ----------

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Fetch Federal Reserve press releases for a month.")
    ap.add_argument("--year", type=int, required=True, help="e.g., 2025")
    ap.add_argument("--month", type=int, required=True, help="1-12")
    ap.add_argument("--out", type=str, default="fed_press_out", help="Output directory root")
    args = ap.parse_args()

    if not (1 <= args.month <= 12):
        raise SystemExit("Month must be 1..12")

    try:
        fetch_month(args.year, args.month, args.out)
    except Exception as e:
        raise SystemExit(f"[error] {e}")

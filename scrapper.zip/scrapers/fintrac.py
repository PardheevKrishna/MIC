#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FINTRAC / CANAFE News scraper (robust date/link pairing)
- Scrapes https://fintrac-canafe.canada.ca/new-neuf/1-eng
- Matches ANY ISO date "YYYY-MM-DD" that appears in the same container as a link
  (table rows, list items, paragraphs, generic divs).
- Follows each link (FINTRAC or external) and saves cleaned text:
      YYYY-MM-DD <Title>.txt
- Emits manifest.csv

Usage:
  pip install requests beautifulsoup4 lxml
  python fintrac.py --year 2025 --month 10
"""

import csv
import os
import re
import time
import html
import pathlib
from typing import List, Tuple, Dict, Optional
from urllib.parse import urljoin, urlparse
import datetime as dt

import requests
from bs4 import BeautifulSoup

BASE = "https://fintrac-canafe.canada.ca"
INDEX_URL = BASE + "/new-neuf/1-eng"

SESSION = requests.Session()
SESSION.headers.update({
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/127.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-CA,en-US;q=0.9,en;q=0.8",
    "Connection": "keep-alive",
    "Referer": INDEX_URL,
})

# Patterns
ISO_DATE = re.compile(r"\b(20\d{2})-(\d{2})-(\d{2})\b")  # 2000–2099
DATE_IN_URL_RE = re.compile(r"/(20\d{2})-(\d{2})-(\d{2})(?:\D|$)")
MAX_FILENAME_LEN = 150

def safe_filename(s: str, maxlen: int = MAX_FILENAME_LEN) -> str:
    s = re.sub(r"[^\w\-.() ]+", "_", s.strip())
    s = re.sub(r"[ _]{2,}", " ", s)
    if len(s) > maxlen:
        stem, ext = os.path.splitext(s)
        s = stem[: maxlen - len(ext) - 1] + "_" + ext
    return s or "file"

def ensure_unique_path(path: pathlib.Path) -> pathlib.Path:
    if not path.exists():
        return path
    stem, ext = path.stem, path.suffix
    i = 2
    while True:
        cand = path.with_name(f"{stem} ({i}){ext}")
        if not cand.exists():
            return cand
        i += 1

def get_soup(url: str, timeout: int = 20) -> BeautifulSoup:  # Reduced from 30
    r = SESSION.get(url, timeout=timeout)
    r.raise_for_status()
    return BeautifulSoup(r.text, "lxml")

def parse_date_from_text(text: str) -> Optional[dt.date]:
    m = ISO_DATE.search(text or "")
    if not m:
        return None
    y, mm, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
    try:
        return dt.date(y, mm, dd)
    except ValueError:
        return None

def parse_date_from_url(url: str) -> Optional[dt.date]:
    m = DATE_IN_URL_RE.search(url)
    if not m:
        return None
    y, mm, dd = int(m.group(1)), int(m.group(2)), int(m.group(3))
    try:
        return dt.date(y, mm, dd)
    except ValueError:
        return None

def month_matches(d: dt.date, year: int, month: int) -> bool:
    return d.year == year and d.month == month

def nearest_container(node):
    """
    Climb to a reasonable container that likely holds both date and link,
    favoring table rows and list items.
    """
    preferred = {"tr", "li"}
    generic = {"p", "div", "article", "section", "dd", "dt"}
    el = node
    # climb up a few levels at most
    for _ in range(6):
        if not el or not getattr(el, "name", None):
            break
        if el.name in preferred:
            return el
        el = el.parent
    # second pass: generic containers
    el = node
    for _ in range(6):
        if not el or not getattr(el, "name", None):
            break
        if el.name in generic:
            return el
        el = el.parent
    return node.parent or node

def extract_index_items(index_soup: BeautifulSoup) -> List[Tuple[dt.date, str, str]]:
    """
    Extract rows where an ISO date appears in the same container as a link.
    Returns: list of (date, absolute_url, link_text)
    """
    main = index_soup.find("main") or index_soup.find(id="wb-main-in") or index_soup
    items: List[Tuple[dt.date, str, str]] = []

    # Strategy A: table rows (common on GC sites)
    for tr in main.select("tr"):
        row_text = tr.get_text(" ", strip=True)
        d = parse_date_from_text(row_text)
        if not d:
            continue
        a = tr.find("a", href=True)
        if not a:
            continue
        url = urljoin(BASE, a["href"])
        title = a.get_text(" ", strip=True) or "Untitled"
        items.append((d, url, title))

    # Strategy B: list items / paragraphs / generic containers
    # This complements Strategy A in case the page uses lists instead of tables.
    if not items:
        for a in main.find_all("a", href=True):
            container = nearest_container(a)
            ctx = container.get_text(" ", strip=True)
            d = parse_date_from_text(ctx)
            if not d:
                # last resort: infer from URL if it embeds the date
                d = parse_date_from_url(a["href"])
            if not d:
                continue
            url = urljoin(BASE, a["href"])
            title = a.get_text(" ", strip=True) or "Untitled"
            items.append((d, url, title))

    # Deduplicate by URL, keep first
    seen = set()
    out: List[Tuple[dt.date, str, str]] = []
    for d, u, t in items:
        if u not in seen:
            out.append((d, u, t))
            seen.add(u)
    return out

def extract_title(soup: BeautifulSoup) -> str:
    h1 = soup.find("h1")
    if h1 and h1.get_text(strip=True):
        return h1.get_text(strip=True)
    if soup.title and soup.title.string:
        return soup.title.string.strip()
    return "Untitled"

def extract_main_text_generic(soup: BeautifulSoup) -> str:
    selectors = [
        "main article", "article", "main",
        "#wb-main-in", "#wb-cont", "#content", "#main",
        "section[role='main']", "section.content", "div#main", "div.content"
    ]
    candidates = []
    for s in selectors:
        candidates.extend(soup.select(s))
    root = candidates[0] if candidates else (soup.body or soup)

    for tag in root.select("script, style, nav, aside, header, footer, form"):
        tag.decompose()

    text = root.get_text("\n", strip=True)
    text = html.unescape(re.sub(r"\n{2,}", "\n\n", text))
    return text

def fetch_and_save_article(url: str, date: dt.date, out_dir: pathlib.Path) -> Tuple[str, str]:
    soup = get_soup(url)
    title = extract_title(soup)
    text = extract_main_text_generic(soup)
    fname = safe_filename(f"{date.isoformat()} {title}.txt")
    fpath = ensure_unique_path(out_dir / fname)
    fpath.parent.mkdir(parents=True, exist_ok=True)
    fpath.write_text(text, encoding="utf-8")
    return str(fpath), title

def crawl_month(year: int, month: int, out_root: str = "fintrac_out") -> Dict:
    out_dir = pathlib.Path(out_root) / f"{year}-{month:02d}" / "html_text"
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"[index] {INDEX_URL}")
    soup = get_soup(INDEX_URL)

    rows = extract_index_items(soup)
    # Keep only target month/year
    rows = [r for r in rows if month_matches(r[0], year, month)]
    rows.sort(key=lambda x: x[0])

    if not rows:
        print(f"[info] No items found for {year}-{month:02d}.")
    else:
        print(f"[info] Found {len(rows)} items for {year}-{month:02d}.")

    manifest: List[Dict[str, str]] = []
    for i, (date, url, _link_text) in enumerate(rows, start=1):
        try:
            saved_path, title = fetch_and_save_article(url, date, out_dir)
            print(f"  - saved ({i}/{len(rows)}): {saved_path}")
            manifest.append({
                "date": date.isoformat(),
                "title": title,
                "source_url": url,
                "saved_file": saved_path,
                "domain": urlparse(url).netloc or urlparse(BASE).netloc,
            })
            time.sleep(0.15)  # Reduced from 0.4
        except Exception as exc:
            print(f"  ! failed ({i}/{len(rows)}): {url} -> {exc}")

    manifest_path = out_dir.parent / "manifest.csv"
    with open(manifest_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f, fieldnames=["date", "title", "source_url", "saved_file", "domain"]
        )
        writer.writeheader()
        for row in manifest:
            writer.writerow(row)

    print(f"[done] Collected {len(manifest)} articles for {year}-{month:02d}")
    print(f"[done] Output dir: {(out_dir.parent).resolve()}")
    print(f"[done] Manifest: {manifest_path.resolve()}")

    return {
        "year": year,
        "month": month,
        "count": len(manifest),
        "output_dir": str(out_dir.parent.resolve()),
        "manifest": str(manifest_path.resolve()),
    }

# ---------- CLI ----------

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Scrape FINTRAC/CANAFE news items for a given month.")
    ap.add_argument("--year", type=int, required=True, help="e.g., 2025")
    ap.add_argument("--month", type=int, required=True, help="1-12")
    ap.add_argument("--out", type=str, default="fintrac_out", help="Output directory root")
    args = ap.parse_args()

    if not (1 <= args.month <= 12):
        raise SystemExit("Month must be 1..12")

    try:
        crawl_month(args.year, args.month, args.out)
    except Exception as e:
        raise SystemExit(f"[error] {e}")

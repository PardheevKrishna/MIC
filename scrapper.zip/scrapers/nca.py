#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NCA Publications harvester (month/year filter, robust row/date detection, PDF downloader)
"""

import csv, os, re, html, time, random, pathlib, datetime as dt
from typing import List, Optional, Dict, Tuple
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

BASE  = "https://www.nationalcrimeagency.gov.uk"
INDEX = BASE + "/who-we-are/publications"

SESSION = requests.Session()
SESSION.headers.update({
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
    "Connection": "keep-alive",
})

REQUEST_TIMEOUT   = 20  # Reduced from 45
PAUSE_RANGE       = (0.05, 0.15)  # Reduced from (0.12, 0.28)
RETRY_BACKOFF     = 0.6
MAX_FILENAME_LEN  = 150

MONTHS = {
    "jan":1,"feb":2,"mar":3,"apr":4,"may":5,"jun":6,
    "jul":7,"aug":8,"sep":9,"sept":9,"oct":10,"nov":11,"dec":12
}
DATE_RE = re.compile(r"\b(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\s+(20\d{2})\b", re.I)

def snooze(): time.sleep(random.uniform(*PAUSE_RANGE))

def safe_filename(s: str, maxlen: int = MAX_FILENAME_LEN) -> str:
    s = html.unescape(s or "").strip()
    s = re.sub(r"\s*\((?:pdf|docx?|xlsx?|kb|mb|downloads?)[^)]*\)", "", s, flags=re.I)
    s = re.sub(r"[^\w\-.() ]+", "_", s)
    s = re.sub(r"[ _]{2,}", " ", s)
    if len(s) > maxlen:
        stem, ext = os.path.splitext(s); s = stem[: maxlen-len(ext)-1] + "_" + ext
    return s or "file"

def ensure_unique(path: pathlib.Path) -> pathlib.Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists(): return path
    stem, ext = path.stem, path.suffix; i = 2
    while True:
        cand = path.with_name(f"{stem} ({i}){ext}")
        if not cand.exists(): return cand
        i += 1

def get(url: str, accept: Optional[str] = None, retries: int = 3) -> Optional[requests.Response]:
    for k in range(retries):
        try:
            hdrs = {"Referer": INDEX}
            if accept: hdrs["Accept"] = accept
            r = SESSION.get(url, timeout=REQUEST_TIMEOUT, headers=hdrs, allow_redirects=True)
            if 200 <= r.status_code < 300: return r
            if r.status_code in (403, 406, 429) or 500 <= r.status_code < 600:
                time.sleep(RETRY_BACKOFF * (2**k) + random.uniform(0, 0.25)); continue
            return None
        except requests.RequestException:
            time.sleep(RETRY_BACKOFF * (2**k) + random.uniform(0, 0.25))
    return None

def soup_get(url: str) -> Optional[BeautifulSoup]:
    r = get(url, accept="text/html,application/xhtml+xml;q=0.9,*/*;q=0.8")
    if not r: return None
    return BeautifulSoup(r.text, "lxml")

def parse_date(text: str) -> Optional[dt.date]:
    # take the LAST date-like token in the row (the row can contain multiple numbers)
    matches = list(DATE_RE.finditer(text or ""))
    if not matches: return None
    m = matches[-1]
    day = int(m.group(1)); mon = MONTHS[m.group(2).lower()]; year = int(m.group(3))
    try: return dt.date(year, mon, day)
    except ValueError: return None

def yield_rows(soup: BeautifulSoup):
    """
    Yield tuples (element, anchor, href, title, row_text).
    We accept any <li> or <tr> that contains an <a> to /who-we-are/publications/…
    This covers both direct '/file' links and detail pages.
    """
    seen = set()
    
    # First, try table rows (tbody > tr)
    tbody = soup.find("tbody")
    if tbody:
        for tr in tbody.find_all("tr"):
            # Find the main link (usually the second <a> with the actual title)
            links = tr.find_all("a", href=True)
            if not links: continue
            
            # Prefer the link with the longest text (usually the title, not "pdf"/"document")
            a = max(links, key=lambda x: len(x.get_text(strip=True)))
            
            href = a.get("href") or ""
            if "/who-we-are/publications/" not in href:
                continue
            absu = urljoin(BASE, href)
            title = a.get_text(" ", strip=True)
            if not title or title.lower() in ("pdf", "doc", "docx", "document"): 
                continue
            row_text = tr.get_text(" ", strip=True)
            key = (absu, title)
            if key in seen: continue
            seen.add(key)
            yield tr, absu, title, row_text
    
    # Fallback: try list items (li)
    scope_lists = soup.select("ul, .listing, .pub-list")
    if not scope_lists: scope_lists = [soup]
    for ul in scope_lists:
        for li in ul.select("li"):
            a = li.select_one("a[href]")
            if not a: continue
            href = a.get("href") or ""
            if "/who-we-are/publications/" not in href:  # stay in the publications section
                continue
            absu = urljoin(BASE, href)
            title = a.get_text(" ", strip=True)
            if not title: continue
            row_text = li.get_text(" ", strip=True)
            key = (absu, title)
            if key in seen: continue
            seen.add(key)
            yield li, absu, title, row_text

def resolve_pdf(detail_or_file_url: str) -> Optional[str]:
    # already a /file link?
    if detail_or_file_url.endswith("/file") or detail_or_file_url.lower().endswith(".pdf"):
        return detail_or_file_url
    soup = soup_get(detail_or_file_url)
    if not soup: return None
    # common patterns on detail pages
    for a in soup.select("a[href]"):
        href = a.get("href") or ""
        if href.endswith("/file") or href.lower().endswith(".pdf"):
            return urljoin(detail_or_file_url, href)
    return None

def crawl_month(year: int, month: int, out_root: str = "nca_out") -> Dict:
    out_root = pathlib.Path(out_root)
    month_root = out_root / f"{year}-{month:02d}"
    pdf_dir = month_root / "pdfs"
    pdf_dir.mkdir(parents=True, exist_ok=True)

    url = INDEX
    seen_pages = set()
    fetched = 0
    manifest: List[Dict[str, str]] = []

    while url and url not in seen_pages:
        seen_pages.add(url)
        print(f"[index] {url}")
        soup = soup_get(url)
        if not soup:
            print("  - [warn] failed to fetch page; stopping.")
            break

        for li, link_url, raw_title, row_text in yield_rows(soup):
            d = parse_date(row_text)
            if not d or not (d.year == year and d.month == month):
                continue

            # Clean the title more aggressively
            title = raw_title
            # Remove parenthetical file info like (pdf, 271 KB) or (docx, 906 KB)
            title = re.sub(r"\s*\([^)]*(?:pdf|docx?|xlsx?|kb|mb)[^)]*\)", "", title, flags=re.I)
            # Remove any remaining parenthetical content with numbers and units
            title = re.sub(r"\s*\(\s*[\d.]+\s*(?:kb|mb|gb)\s*\)", "", title, flags=re.I)
            title = safe_filename(title)
            
            pdf_url = resolve_pdf(link_url) or link_url  # fallback: try the link as-is
            fname = f"{d.isoformat()} {title}.pdf"
            fpath = ensure_unique(pdf_dir / fname)

            r = get(pdf_url, accept="application/pdf,application/octet-stream;q=0.9,*/*;q=0.8", retries=4)
            if not r:
                print(f"  - [skip] could not download: {pdf_url}")
                continue
            with open(fpath, "wb") as f:
                f.write(r.content)

            fetched += 1
            print(f"  - saved ({fetched}): {fpath.name} [{len(r.content)} bytes]")
            manifest.append({
                "date": d.isoformat(),
                "title": title,
                "file_url": pdf_url,
                "saved_file": str(fpath.resolve()),
                "bytes": str(len(r.content)),
                "source_row_url": link_url,
            })
            snooze()

        # pagination — follow “Next”
        next_link = None
        for a in soup.select("a[rel='next'], a[aria-label='Next'], .pagination a"):
            t = a.get_text(" ", strip=True).lower()
            if t in ("next", "next »", "»", "›"):
                next_link = urljoin(url, a.get("href") or "")
                break
        url = next_link

    manifest_path = month_root / "manifest.csv"
    with open(manifest_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["date","title","file_url","saved_file","bytes","source_row_url"])
        writer.writeheader()
        for row in sorted(manifest, key=lambda r: r["date"]):
            writer.writerow(row)

    print(f"[done] Collected {fetched} PDFs for {year}-{month:02d}")
    print(f"[done] Output dir: {month_root.resolve()}")
    print(f"[done] Manifest: {manifest_path.resolve()}")
    return {"count": fetched, "output_dir": str(month_root.resolve()), "manifest": str(manifest_path.resolve())}

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="NCA Publications harvester (month/year PDF downloader).")
    ap.add_argument("--year", type=int, required=True)
    ap.add_argument("--month", type=int, required=True)
    ap.add_argument("--out", type=str, default="nca_out")
    args = ap.parse_args()
    if not (1 <= args.month <= 12): raise SystemExit("Month must be 1..12")
    crawl_month(args.year, args.month, args.out)

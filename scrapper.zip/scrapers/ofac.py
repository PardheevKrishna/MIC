#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OFAC Press Releases harvester (month/year filter, text extractor)
"""

import csv, os, re, html, time, random, pathlib, datetime as dt
from typing import List, Optional, Dict
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

BASE  = "https://ofac.treasury.gov"
INDEX = BASE + "/press-releases"

SESSION = requests.Session()
SESSION.headers.update({
    "User-Agent": "FinancialComplianceBot/1.0 (research@example.com)",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate",
    "Connection": "keep-alive",
})

REQUEST_TIMEOUT   = 20  # Reduced from 45
PAUSE_RANGE       = (0.1, 0.3)  # Reduced from (0.3, 0.6)
RETRY_BACKOFF     = 0.8
MAX_FILENAME_LEN  = 150

def snooze(): time.sleep(random.uniform(*PAUSE_RANGE))

def safe_filename(s: str, maxlen: int = MAX_FILENAME_LEN) -> str:
    s = html.unescape(s or "").strip()
    s = re.sub(r"[^\w\-.() ]+", "_", s)
    s = re.sub(r"[ _]{2,}", " ", s)
    if len(s) > maxlen:
        stem, ext = os.path.splitext(s)
        s = stem[: maxlen-len(ext)-1] + "_" + ext
    return s or "file"

def ensure_unique(path: pathlib.Path) -> pathlib.Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists(): return path
    stem, ext = path.stem, path.suffix
    i = 2
    while True:
        cand = path.with_name(f"{stem} ({i}){ext}")
        if not cand.exists(): return cand
        i += 1

def get(url: str, retries: int = 3) -> Optional[requests.Response]:
    for k in range(retries):
        try:
            hdrs = {"Referer": INDEX}
            r = SESSION.get(url, timeout=REQUEST_TIMEOUT, headers=hdrs, allow_redirects=True)
            if 200 <= r.status_code < 300: return r
            if r.status_code in (403, 429) or 500 <= r.status_code < 600:
                time.sleep(RETRY_BACKOFF * (2**k) + random.uniform(0, 0.3))
                continue
            return None
        except requests.RequestException:
            time.sleep(RETRY_BACKOFF * (2**k) + random.uniform(0, 0.3))
    return None

def soup_get(url: str) -> Optional[BeautifulSoup]:
    r = get(url)
    if not r: return None
    return BeautifulSoup(r.text, "lxml")

def parse_date(text: str) -> Optional[dt.date]:
    """Parse dates like '2025-11-04' or '2025-10-30'"""
    m = re.search(r"(\d{4})-(\d{1,2})-(\d{1,2})", text or "")
    if not m: return None
    year = int(m.group(1))
    month = int(m.group(2))
    day = int(m.group(3))
    try:
        return dt.date(year, month, day)
    except ValueError:
        return None

def extract_press_release_text(url: str) -> Optional[str]:
    """Fetch the press release detail page and extract the main text content."""
    soup = soup_get(url)
    if not soup: return None
    
    # Remove navigation and sidebar elements
    for unwanted in soup.select("nav, .navigation, .sidebar, .menu, header, footer, .breadcrumb"):
        unwanted.decompose()
    
    # Try multiple selectors for the main content
    content = None
    
    # Common press release content selectors
    for selector in [
        "article .field--name-body",
        ".press-release-content",
        ".news-article-content",
        "article .content",
        "article",
        ".main-content",
        "main",
    ]:
        content = soup.select_one(selector)
        if content: break
    
    if not content:
        # Fallback: try to find the main content div
        content = soup.find("div", class_=lambda x: x and ("content" in x.lower() or "body" in x.lower()))
    
    if not content:
        # Last resort: get all paragraph text from main content area
        main = soup.find("main") or soup.find("div", {"role": "main"})
        if main:
            paragraphs = main.find_all("p")
        else:
            paragraphs = soup.find_all("p")
        
        if paragraphs:
            return "\n\n".join(p.get_text(strip=True) for p in paragraphs if p.get_text(strip=True))
        return None
    
    # Clean up the text
    text = content.get_text("\n", strip=True)
    # Remove excessive newlines
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text

def yield_press_releases(soup: BeautifulSoup):
    """
    Yield tuples (date_text, title, press_link, actions_notice_text, actions_link) from the table.
    """
    table = soup.find("table")
    if not table:
        return
    
    tbody = table.find("tbody")
    if not tbody:
        return
    
    seen = set()
    for tr in tbody.find_all("tr"):
        cells = tr.find_all("td")
        if len(cells) < 3:
            continue
        
        # Cell 0: Press Release Link (title + link)
        # Cell 1: Associated Recent Actions Notice (text + link)
        # Cell 2: Date
        
        press_release_cell = cells[0]
        press_link_tag = press_release_cell.find("a", href=True)
        if not press_link_tag:
            continue
        
        title = press_link_tag.get_text(strip=True)
        press_href = press_link_tag["href"]
        press_abs_url = urljoin(BASE, press_href)
        
        # Recent actions notice
        actions_cell = cells[1]
        actions_text = actions_cell.get_text(strip=True)
        actions_link = ""
        actions_link_tag = actions_cell.find("a", href=True)
        if actions_link_tag:
            actions_link = urljoin(BASE, actions_link_tag["href"])
        
        # Date
        date_text = cells[2].get_text(strip=True)
        
        key = (press_abs_url, title)
        if key in seen:
            continue
        seen.add(key)
        
        yield date_text, title, press_abs_url, actions_text, actions_link

def crawl_month(year: int, month: int, out_root: str = "ofac_out") -> Dict:
    out_root = pathlib.Path(out_root)
    month_root = out_root / f"{year}-{month:02d}"
    text_dir = month_root / "html_text"
    pdf_dir = month_root / "pdfs"
    text_dir.mkdir(parents=True, exist_ok=True)
    pdf_dir.mkdir(parents=True, exist_ok=True)

    url = INDEX
    seen_pages = set()
    fetched = 0
    manifest: List[Dict[str, str]] = []
    found_previous_month = False

    while url and url not in seen_pages and not found_previous_month:
        seen_pages.add(url)
        print(f"[index] {url}")
        soup = soup_get(url)
        if not soup:
            print("  - [warn] failed to fetch page; stopping.")
            break

        for date_text, title, press_link, actions_text, actions_link in yield_press_releases(soup):
            d = parse_date(date_text)
            if not d:
                continue
            
            # Stop if we've reached the previous month
            if d.year < year or (d.year == year and d.month < month):
                print(f"  - [info] reached previous month ({d.isoformat()}), stopping pagination.")
                found_previous_month = True
                break
            
            # Skip if not the target month
            if not (d.year == year and d.month == month):
                continue

            # Determine if this is a direct PDF/download link or a page
            is_pdf = press_link.endswith('.pdf') or '/download' in press_link
            
            if is_pdf:
                # It's a direct file download (like CHART files) - download as PDF
                print(f"  - downloading PDF: {title[:80]}...")
                r = get(press_link, retries=4)
                if not r:
                    print(f"    [skip] could not download: {press_link}")
                    continue
                
                safe_title = safe_filename(title)
                fname = f"{d.isoformat()} {safe_title}.pdf"
                fpath = ensure_unique(pdf_dir / fname)
                
                with open(fpath, "wb") as f:
                    f.write(r.content)
                
                fetched += 1
                print(f"    saved ({fetched}): {fpath.name} [{len(r.content)} bytes]")
                
                manifest.append({
                    "date": d.isoformat(),
                    "title": title,
                    "actions_notice": actions_text,
                    "press_url": press_link,
                    "actions_url": actions_link,
                    "saved_file": str(fpath.resolve()),
                    "bytes": str(len(r.content)),
                    "type": "pdf"
                })
            else:
                # Fetch the full press release text
                print(f"  - fetching: {title[:80]}...")
                text_content = extract_press_release_text(press_link)
                if not text_content:
                    print(f"    [skip] could not extract text from: {press_link}")
                    continue

                # Save as text file
                safe_title = safe_filename(title)
                fname = f"{d.isoformat()} {safe_title}.txt"
                fpath = ensure_unique(text_dir / fname)

                with open(fpath, "w", encoding="utf-8") as f:
                    f.write(f"Title: {title}\n")
                    f.write(f"Date: {date_text}\n")
                    f.write(f"Associated Actions: {actions_text}\n")
                    f.write(f"Press Release URL: {press_link}\n")
                    if actions_link:
                        f.write(f"Actions Notice URL: {actions_link}\n")
                    f.write(f"\n{'='*80}\n\n")
                    f.write(text_content)

                fetched += 1
                print(f"    saved ({fetched}): {fpath.name} [{len(text_content)} chars]")
                
                manifest.append({
                    "date": d.isoformat(),
                    "title": title,
                    "actions_notice": actions_text,
                    "press_url": press_link,
                    "actions_url": actions_link,
                    "saved_file": str(fpath.resolve()),
                    "chars": str(len(text_content)),
                    "type": "text"
                })
            
            snooze()

        # Pagination - look for "Next" link
        next_link = None
        pager = soup.find("nav", class_=lambda x: x and "pager" in str(x).lower()) if soup else None
        if pager:
            for a in pager.find_all("a", href=True):
                if "next" in a.get_text().lower() or "›" in a.get_text():
                    next_link = urljoin(url, a["href"])
                    break
        
        # Alternative pagination
        if not next_link:
            for a in soup.find_all("a", href=True):
                link_text = a.get_text(strip=True).lower()
                if link_text in ("next", "next »", "›", "next page"):
                    next_link = urljoin(url, a["href"])
                    break
        
        url = next_link

    manifest_path = month_root / "manifest.csv"
    with open(manifest_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["date","title","actions_notice","press_url","actions_url","saved_file","type","size"])
        writer.writeheader()
        for row in sorted(manifest, key=lambda r: r["date"]):
            # Add size field based on type
            if row["type"] == "pdf":
                row["size"] = row.pop("bytes", "")
            else:
                row["size"] = row.pop("chars", "")
            writer.writerow(row)

    print(f"\n[done] Collected {fetched} press releases for {year}-{month:02d}")
    print(f"[done] Output dir: {month_root.resolve()}")
    print(f"[done] Manifest: {manifest_path.resolve()}")
    return {
        "count": fetched,
        "output_dir": str(month_root.resolve()),
        "manifest": str(manifest_path.resolve())
    }

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="OFAC Press Releases harvester (month/year text downloader).")
    ap.add_argument("--year", type=int, required=True)
    ap.add_argument("--month", type=int, required=True)
    ap.add_argument("--out", type=str, default="ofac_out")
    args = ap.parse_args()
    if not (1 <= args.month <= 12):
        raise SystemExit("Month must be 1..12")
    crawl_month(args.year, args.month, args.out)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SEC Press Releases harvester (month/year filter, text extractor)
"""

import csv, os, re, html, time, random, pathlib, datetime as dt
from typing import List, Optional, Dict
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

BASE  = "https://www.sec.gov"
INDEX = BASE + "/newsroom/press-releases"

SESSION = requests.Session()
SESSION.headers.update({
    "User-Agent": "FinancialComplianceBot/1.0 (research@example.com)",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate",
    "Connection": "keep-alive",
})

REQUEST_TIMEOUT   = 20  # Reduced from 45
PAUSE_RANGE       = (0.1, 0.3)  # Reduced from (0.3, 0.6)
RETRY_BACKOFF     = 0.8
MAX_FILENAME_LEN  = 150

MONTHS = {
    "jan":1,"january":1,"feb":2,"february":2,"mar":3,"march":3,
    "apr":4,"april":4,"may":5,"jun":6,"june":6,"jul":7,"july":7,
    "aug":8,"august":8,"sep":9,"sept":9,"september":9,
    "oct":10,"october":10,"nov":11,"november":11,"dec":12,"december":12
}
DATE_RE = re.compile(r"\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\.?\s+(\d{1,2}),\s+(20\d{2})\b", re.I)

def snooze(): time.sleep(random.uniform(*PAUSE_RANGE))

def safe_filename(s: str, maxlen: int = MAX_FILENAME_LEN) -> str:
    s = html.unescape(s or "").strip()
    s = re.sub(r"[^\w\-.() ]+", "_", s)
    s = re.sub(r"[ _]{2,}", " ", s)
    if len(s) > maxlen:
        stem, ext = os.path.splitext(s)
        s = stem[: maxlen-len(ext)-1] + "_" + ext
    return s or "file"

def ensure_unique(path: pathlib.Path) -> pathlib.Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists(): return path
    stem, ext = path.stem, path.suffix
    i = 2
    while True:
        cand = path.with_name(f"{stem} ({i}){ext}")
        if not cand.exists(): return cand
        i += 1

def get(url: str, retries: int = 3) -> Optional[requests.Response]:
    for k in range(retries):
        try:
            hdrs = {"Referer": INDEX}
            r = SESSION.get(url, timeout=REQUEST_TIMEOUT, headers=hdrs, allow_redirects=True)
            if 200 <= r.status_code < 300: return r
            if r.status_code in (403, 429) or 500 <= r.status_code < 600:
                time.sleep(RETRY_BACKOFF * (2**k) + random.uniform(0, 0.3))
                continue
            return None
        except requests.RequestException:
            time.sleep(RETRY_BACKOFF * (2**k) + random.uniform(0, 0.3))
    return None

def soup_get(url: str) -> Optional[BeautifulSoup]:
    r = get(url)
    if not r: return None
    return BeautifulSoup(r.text, "lxml")

def parse_date(text: str) -> Optional[dt.date]:
    """Parse dates like 'Oct. 31, 2025' or 'Sept. 30, 2025'"""
    m = DATE_RE.search(text or "")
    if not m: return None
    mon_str = m.group(1).lower().rstrip('.')
    day = int(m.group(2))
    year = int(m.group(3))
    mon = MONTHS.get(mon_str)
    if not mon: return None
    try:
        return dt.date(year, mon, day)
    except ValueError:
        return None

def extract_press_release_text(url: str) -> Optional[str]:
    """Fetch the press release detail page and extract the main text content."""
    soup = soup_get(url)
    if not soup: return None
    
    # Remove navigation and sidebar elements
    for unwanted in soup.select("nav, .navigation, .sidebar, .menu, header, footer, .breadcrumb"):
        unwanted.decompose()
    
    # Try multiple selectors for the main content
    content = None
    
    # Common SEC press release content selectors
    for selector in [
        "article .field--name-body",
        ".press-release-content",
        ".news-article-content",
        "article .content",
        "article",
        ".main-content",
        "main",
    ]:
        content = soup.select_one(selector)
        if content: break
    
    if not content:
        # Fallback: try to find the main content div
        content = soup.find("div", class_=lambda x: x and ("content" in x.lower() or "body" in x.lower()))
    
    if not content:
        # Last resort: get all paragraph text from main content area
        main = soup.find("main") or soup.find("div", {"role": "main"})
        if main:
            paragraphs = main.find_all("p")
        else:
            paragraphs = soup.find_all("p")
        
        if paragraphs:
            return "\n\n".join(p.get_text(strip=True) for p in paragraphs if p.get_text(strip=True))
        return None
    
    # Clean up the text
    text = content.get_text("\n", strip=True)
    # Remove excessive newlines
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text

def yield_press_releases(soup: BeautifulSoup):
    """
    Yield tuples (date_text, title, link, release_no) from the table.
    """
    tbody = soup.find("tbody")
    if not tbody:
        return
    
    seen = set()
    for tr in tbody.find_all("tr"):
        cells = tr.find_all("td")
        if len(cells) < 2:
            continue
        
        # Cell 0: Date
        # Cell 1: Headline (with link)
        # Cell 2: Release No. (if exists)
        date_text = cells[0].get_text(strip=True)
        
        headline_cell = cells[1]
        link_tag = headline_cell.find("a", href=True)
        if not link_tag:
            continue
        
        title = link_tag.get_text(strip=True)
        href = link_tag["href"]
        abs_url = urljoin(BASE, href)
        
        release_no = ""
        if len(cells) >= 3:
            release_no = cells[2].get_text(strip=True)
        
        key = (abs_url, title)
        if key in seen:
            continue
        seen.add(key)
        
        yield date_text, title, abs_url, release_no

def crawl_month(year: int, month: int, out_root: str = "sec_out") -> Dict:
    out_root = pathlib.Path(out_root)
    month_root = out_root / f"{year}-{month:02d}"
    text_dir = month_root / "html_text"
    text_dir.mkdir(parents=True, exist_ok=True)

    url = INDEX
    seen_pages = set()
    fetched = 0
    manifest: List[Dict[str, str]] = []
    found_previous_month = False

    while url and url not in seen_pages and not found_previous_month:
        seen_pages.add(url)
        print(f"[index] {url}")
        soup = soup_get(url)
        if not soup:
            print("  - [warn] failed to fetch page; stopping.")
            break

        for date_text, title, link_url, release_no in yield_press_releases(soup):
            d = parse_date(date_text)
            if not d:
                continue
            
            # Stop if we've reached the previous month
            if d.year < year or (d.year == year and d.month < month):
                print(f"  - [info] reached previous month ({d.isoformat()}), stopping pagination.")
                found_previous_month = True
                break
            
            # Skip if not the target month
            if not (d.year == year and d.month == month):
                continue

            # Fetch the full press release text
            print(f"  - fetching: {title[:80]}...")
            text_content = extract_press_release_text(link_url)
            if not text_content:
                print(f"    [skip] could not extract text from: {link_url}")
                continue

            # Save as text file
            safe_title = safe_filename(title)
            fname = f"{d.isoformat()} {safe_title}.txt"
            fpath = ensure_unique(text_dir / fname)

            with open(fpath, "w", encoding="utf-8") as f:
                f.write(f"Title: {title}\n")
                f.write(f"Date: {date_text}\n")
                f.write(f"Release No.: {release_no}\n")
                f.write(f"URL: {link_url}\n")
                f.write(f"\n{'='*80}\n\n")
                f.write(text_content)

            fetched += 1
            print(f"    saved ({fetched}): {fpath.name} [{len(text_content)} chars]")
            
            manifest.append({
                "date": d.isoformat(),
                "title": title,
                "release_no": release_no,
                "url": link_url,
                "saved_file": str(fpath.resolve()),
                "chars": str(len(text_content)),
            })
            
            snooze()

        # Pagination - look for "Next" link
        next_link = None
        pager = soup.find("nav", class_=lambda x: x and "pager" in x.lower()) if soup else None
        if pager:
            for a in pager.find_all("a", href=True):
                if "next" in a.get_text().lower() or "›" in a.get_text():
                    next_link = urljoin(url, a["href"])
                    break
        
        # Alternative: look for pagination links
        if not next_link:
            for a in soup.find_all("a", href=True):
                link_text = a.get_text(strip=True).lower()
                if link_text in ("next", "next »", "›", "next page"):
                    next_link = urljoin(url, a["href"])
                    break
        
        url = next_link

    manifest_path = month_root / "manifest.csv"
    with open(manifest_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["date","title","release_no","url","saved_file","chars"])
        writer.writeheader()
        for row in sorted(manifest, key=lambda r: r["date"]):
            writer.writerow(row)

    print(f"\n[done] Collected {fetched} press releases for {year}-{month:02d}")
    print(f"[done] Output dir: {month_root.resolve()}")
    print(f"[done] Manifest: {manifest_path.resolve()}")
    return {
        "count": fetched,
        "output_dir": str(month_root.resolve()),
        "manifest": str(manifest_path.resolve())
    }

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="SEC Press Releases harvester (month/year text downloader).")
    ap.add_argument("--year", type=int, required=True)
    ap.add_argument("--month", type=int, required=True)
    ap.add_argument("--out", type=str, default="sec_out")
    args = ap.parse_args()
    if not (1 <= args.month <= 12):
        raise SystemExit("Month must be 1..12")
    crawl_month(args.year, args.month, args.out)

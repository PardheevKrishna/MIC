#!/usr/bin/env python3
"""
Unified Web Scraper for Financial Regulatory Bodies

Runs all 9 scrapers in parallel with progress tracking.
Outputs to structured folder: scraped_content/<scraper_name>/{html_text,pdfs}

Usage:
    python web_scraper.py --year 2025 --month 10
    python web_scraper.py --year 2025 --month 10 --output scraped_content
"""

import argparse
import sys
from pathlib import Path
from typing import Dict, Tuple
from tqdm import tqdm
import time
import re

# PDF text extraction
from pdfminer.high_level import extract_text as pdf_extract_text
from pdfminer.layout import LAParams

# Import all scraper modules from scrapers folder
from scrapers import amf
from scrapers import dfs
from scrapers import fca
from scrapers import fed
from scrapers import fincen
from scrapers import fintrac
from scrapers import nca
from scrapers import ofac
from scrapers import sec


# Scraper configurations
SCRAPERS = [
    {
        'name': 'AMF',
        'module': amf,
        'function': 'crawl_month',
        'description': 'Autorité des marchés financiers (France)',
    },
    {
        'name': 'DFS',
        'module': dfs,
        'function': 'crawl_month',
        'description': 'NY Department of Financial Services (USA)',
    },
    {
        'name': 'FCA',
        'module': fca,
        'function': 'crawl_month',
        'description': 'Financial Conduct Authority (UK)',
    },
    {
        'name': 'FED',
        'module': fed,
        'function': 'fetch_month',  # Note: FED uses fetch_month instead
        'description': 'Federal Reserve (USA)',
    },
    {
        'name': 'FinCEN',
        'module': fincen,
        'function': 'crawl_month',
        'description': 'Financial Crimes Enforcement Network (USA)',
    },
    {
        'name': 'FINTRAC',
        'module': fintrac,
        'function': 'crawl_month',
        'description': 'Financial Transactions and Reports Analysis Centre (Canada)',
    },
    {
        'name': 'NCA',
        'module': nca,
        'function': 'crawl_month',
        'description': 'National Crime Agency (UK)',
    },
    {
        'name': 'OFAC',
        'module': ofac,
        'function': 'crawl_month',
        'description': 'Office of Foreign Assets Control (USA)',
    },
    {
        'name': 'SEC',
        'module': sec,
        'function': 'crawl_month',
        'description': 'Securities and Exchange Commission (USA)',
    },
]


def extract_text_from_pdf(pdf_path: Path) -> str:
    """
    Extract clean text from a PDF file using pdfminer.six
    
    Args:
        pdf_path: Path to the PDF file
        
    Returns:
        Extracted and cleaned text
    """
    try:
        # Use LAParams for better layout analysis
        laparams = LAParams(
            line_margin=0.5,
            word_margin=0.1,
            char_margin=2.0,
            boxes_flow=0.5,
            detect_vertical=True
        )
        
        # Extract text
        text = pdf_extract_text(str(pdf_path), laparams=laparams)
        
        # Clean up the text
        # Remove excessive whitespace while preserving paragraph structure
        text = re.sub(r'\n{3,}', '\n\n', text)  # Max 2 consecutive newlines
        text = re.sub(r'[ \t]+', ' ', text)      # Normalize spaces
        text = re.sub(r' \n', '\n', text)        # Remove trailing spaces before newlines
        text = text.strip()
        
        return text
    except Exception as e:
        return f"[Error extracting PDF text: {str(e)}]"


def process_pdfs_to_text(pdf_dir: Path, output_text_dir: Path) -> int:
    """
    Extract text from all PDFs in a directory and save as .txt files
    
    Args:
        pdf_dir: Directory containing PDF files
        output_text_dir: Directory to save extracted text files
        
    Returns:
        Number of PDFs processed
    """
    if not pdf_dir.exists():
        return 0
    
    output_text_dir.mkdir(parents=True, exist_ok=True)
    pdf_files = list(pdf_dir.rglob("*.pdf"))
    
    for pdf_path in pdf_files:
        # Create corresponding .txt filename
        txt_filename = pdf_path.stem + ".txt"
        txt_path = output_text_dir / txt_filename
        
        # Skip if already extracted
        if txt_path.exists():
            continue
        
        # Extract and save text
        extracted_text = extract_text_from_pdf(pdf_path)
        
        # Add header with metadata
        header = f"""{'='*80}
PDF: {pdf_path.name}
Extracted: {time.strftime('%Y-%m-%d %H:%M:%S')}
{'='*80}

"""
        
        full_content = header + extracted_text
        
        # Save to file
        txt_path.write_text(full_content, encoding='utf-8', errors='ignore')
    
    return len(pdf_files)


def count_files(directory: Path) -> Tuple[int, int]:
    """Count HTML text files and PDFs in a directory"""
    html_count = 0
    pdf_count = 0
    
    if not directory.exists():
        return 0, 0
    
    # Count in html_text subdirectory
    html_dir = directory / "html_text"
    if html_dir.exists():
        html_count = len([f for f in html_dir.rglob("*.txt")])
    
    # Count in pdfs subdirectory
    pdf_dir = directory / "pdfs"
    if pdf_dir.exists():
        pdf_count = len([f for f in pdf_dir.rglob("*.pdf")])
    
    return html_count, pdf_count


def run_scraper(scraper_config: Dict, year: int, month: int, base_output: Path, pbar: tqdm) -> Dict:
    """Run a single scraper and return statistics"""
    name = scraper_config['name']
    module = scraper_config['module']
    func_name = scraper_config['function']
    
    pbar.set_description(f"Scraping {name:8}")
    
    # Set output directory
    output_dir = base_output / name.lower()
    
    try:
        # Get the scraping function
        scrape_func = getattr(module, func_name)
        
        # Run the scraper
        result = scrape_func(year, month, str(output_dir))
        
        # Count files
        month_dir = output_dir / f"{year}-{month:02d}"
        html_count, pdf_count = count_files(month_dir)
        
        # Extract text from PDFs if any exist
        pdf_text_count = 0
        if pdf_count > 0:
            pdf_dir = month_dir / "pdfs"
            pdf_text_dir = month_dir / "pdf_text"
            pdf_text_count = process_pdfs_to_text(pdf_dir, pdf_text_dir)
        
        return {
            'name': name,
            'status': 'success',
            'html_files': html_count,
            'pdf_files': pdf_count,
            'pdf_text_extracted': pdf_text_count,
            'total_files': html_count + pdf_count,
            'error': None
        }
        
    except Exception as e:
        return {
            'name': name,
            'status': 'failed',
            'html_files': 0,
            'pdf_files': 0,
            'pdf_text_extracted': 0,
            'total_files': 0,
            'error': str(e)
        }


def print_summary(results: list):
    """Print a summary table of scraping results"""
    print("\n" + "=" * 95)
    print(f"{'SCRAPER':<10} {'STATUS':<10} {'HTML':<8} {'PDFs':<8} {'PDF→TXT':<10} {'TOTAL':<8}")
    print("=" * 95)
    
    total_html = 0
    total_pdf = 0
    total_pdf_text = 0
    total_files = 0
    success_count = 0
    
    for result in results:
        status_symbol = "✓" if result['status'] == 'success' else "✗"
        status_text = f"{status_symbol} {result['status'].upper()}"
        
        pdf_text_info = result.get('pdf_text_extracted', 0)
        pdf_text_display = f"{pdf_text_info}" if pdf_text_info > 0 else "-"
        
        print(f"{result['name']:<10} {status_text:<10} {result['html_files']:<8} "
              f"{result['pdf_files']:<8} {pdf_text_display:<10} {result['total_files']:<8}")
        
        if result['status'] == 'success':
            success_count += 1
            total_html += result['html_files']
            total_pdf += result['pdf_files']
            total_pdf_text += result.get('pdf_text_extracted', 0)
            total_files += result['total_files']
        else:
            if result['error']:
                print(f"           Error: {result['error'][:60]}...")
    
    print("=" * 95)
    pdf_text_total_display = f"{total_pdf_text}" if total_pdf_text > 0 else "-"
    print(f"{'TOTAL':<10} {success_count}/{len(results)} OK{'':<6} {total_html:<8} "
          f"{total_pdf:<8} {pdf_text_total_display:<10} {total_files:<8}")
    print("=" * 95)


def main():
    parser = argparse.ArgumentParser(
        description='Run all financial regulatory scrapers for a specific month'
    )
    parser.add_argument('--year', type=int, required=True,
                        help='Year to scrape (e.g., 2025)')
    parser.add_argument('--month', type=int, required=True,
                        help='Month to scrape (1-12)')
    parser.add_argument('--output', type=str, default='scraped_content',
                        help='Base output directory (default: scraped_content)')
    
    args = parser.parse_args()
    
    # Validate month
    if not 1 <= args.month <= 12:
        print(f"Error: Month must be between 1 and 12, got {args.month}")
        sys.exit(1)
    
    # Create base output directory
    base_output = Path(args.output)
    base_output.mkdir(parents=True, exist_ok=True)
    
    print(f"\n{'='*80}")
    print(f"FINANCIAL REGULATORY WEB SCRAPER")
    print(f"{'='*80}")
    print(f"Target: {args.year}-{args.month:02d}")
    print(f"Output: {base_output.absolute()}")
    print(f"Scrapers: {len(SCRAPERS)}")
    print(f"{'='*80}\n")
    
    # Show scraper list
    print("Scrapers to run:")
    for i, scraper in enumerate(SCRAPERS, 1):
        print(f"  {i}. {scraper['name']:<8} - {scraper['description']}")
    print("\n" + "="*80 + "\n")
    
    # Run all scrapers with progress bar
    results = []
    
    # Single progress bar for all scrapers (no nested bars to avoid terminal issues)
    with tqdm(total=len(SCRAPERS), desc="Progress", 
              leave=True, ncols=100, 
              bar_format='{desc}: {bar}| {n_fmt}/{total_fmt} | {elapsed}') as pbar:
        
        for scraper_config in SCRAPERS:
            pbar.set_description(f"Scraping {scraper_config['name']:<8}")
            
            result = run_scraper(scraper_config, args.year, args.month, 
                                base_output, pbar)
            results.append(result)
            
            pbar.update(1)
    
    # Print summary
    print_summary(results)
    
    # Final message
    print(f"\nAll scrapers completed!")
    print(f"Output directory: {base_output.absolute()}")
    
    # Exit with error code if any scraper failed
    failed_count = sum(1 for r in results if r['status'] == 'failed')
    if failed_count > 0:
        print(f"\nWarning: {failed_count} scraper(s) failed")
        sys.exit(1)
    else:
        print(f"\n✓ All scrapers completed successfully!")
        sys.exit(0)


if __name__ == "__main__":
    main()
